SNIP LAB  |  0.2.0-beta  |  WINDOWS TEST BUILD

1. Right-click the ZIP and choose Extract All.
2. Open the extracted Snip-Lab folder and run Launch-Snip-Lab.cmd.
   First launch builds Snip-Lab-0.2.0-beta.exe beside the launcher using the Windows
   .NET Framework 4.x compiler. After that, you can open Snip-Lab-0.2.0-beta.exe directly.
3. Choose About or press F1 for the version, shortcuts and privacy summary.

QUICK TEST
- Choose New snip or press Ctrl+N while Snip Lab is focused. The global
  shortcut Ctrl+Shift+F9 also works while the app is open if available.
  Drag to capture a region. Press Esc to cancel a capture.
- Scroll over the image to zoom. Choose Hand and drag, or hold the middle
  mouse button and drag, to move it. Choose Fit to reset the view.
- Try Arrow, Line, Box, Numbered step and Redact. Ctrl+Z undoes the last mark.
- Ctrl+C copies the annotated image for pasting into Slack or Jira.
  Ctrl+S opens Save image. Choose PNG or JPEG. Saved images contain the full
  snip at its original resolution, with annotations and redactions applied.
- Copy bug template puts the report outline on the clipboard. Paste the
  template first, then copy and paste the screenshot.

SLACK
For direct posting, use a workspace Slack bot with the files:write scope
and access to the destination channel. Choose Slack > Post to channel,
enter its token and channel ID, add an optional comment and confirm.
The app holds the token in memory for the current session. Direct posting
sends the annotated screenshot and optional comment to Slack.

PREVIOUS BUILD TEST STATUS — 10 November 2026
User-reported testing on Windows 11 26H2 confirmed both empty-screen hint
states, and all seven default regression checks passed.

When Ctrl+Shift+F9 is available, the empty screen shows that shortcut.
When it is unavailable, the hint shows New snip or Ctrl+N.

Still open in the test suite
- Complete a capture using New snip when Ctrl+Shift+F9 is unavailable.
- Complete a capture using Ctrl+N when Ctrl+Shift+F9 is unavailable.

Windows testing of the 0.2.0-beta changes is pending. Mixed-DPI behaviour
and live Slack posting remain unverified in this record. This is an unsigned test build. If it fails, note your Windows
version and paste the exact error. For capture issues, include your display
scaling and whether you use multiple monitors.
