@echo off
setlocal
set "root=%~dp0"
set "app=%root%Snip-Lab-0.2.0-beta.exe"
if exist "%app%" goto launch
for %%F in (QA-Snip.cs Slack.cs AppInfo.cs) do if not exist "%root%Source\%%F" goto extract
if not exist "%root%Snip-Lab.ico" goto extract
set "compiler=%SystemRoot%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%compiler%" set "compiler=%SystemRoot%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%compiler%" (
  echo The Windows .NET Framework 4.x compiler could not be found.
  pause
  exit /b 1
)
echo Preparing Snip Lab for its first launch...
"%compiler%" /nologo /target:winexe /optimize+ /out:"%app%" /win32icon:"%root%Snip-Lab.ico" /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll "%root%Source\QA-Snip.cs" "%root%Source\Slack.cs" "%root%Source\AppInfo.cs"
if errorlevel 1 (
  if exist "%app%" del "%app%"
  echo Snip Lab could not build. Keep the compiler error for the bug report.
  pause
  exit /b 1
)
:launch
start "" "%app%"
exit /b 0
:extract
echo Right-click the Snip Lab ZIP and choose Extract All.
echo Open the extracted Snip-Lab folder and run Launch-Snip-Lab.cmd there.
pause
exit /b 1
