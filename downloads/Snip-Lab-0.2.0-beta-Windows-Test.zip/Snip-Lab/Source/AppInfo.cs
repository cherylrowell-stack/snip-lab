﻿using System.Reflection;

[assembly: AssemblyTitle(AppInfo.Name)]
[assembly: AssemblyProduct(AppInfo.Name)]
[assembly: AssemblyDescription(AppInfo.Description)]
[assembly: AssemblyVersion(AppInfo.Version)]
[assembly: AssemblyFileVersion(AppInfo.Version)]
[assembly: AssemblyInformationalVersion(AppInfo.Release)]

internal static class AppInfo
{
    internal const string Name = "Snip Lab";
    internal const string Description = "Screen capture and bug evidence for QA testers and developers.";
    internal const string Version = "0.2.0.0";
    internal const string Release = "0.2.0-beta";
}
