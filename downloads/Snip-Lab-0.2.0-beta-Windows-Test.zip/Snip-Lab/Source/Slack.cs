﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Windows.Forms;

internal sealed class SlackDialog : Form
{
    private readonly TextBox token = new TextBox { UseSystemPasswordChar = true, Dock = DockStyle.Fill };
    private readonly TextBox channel = new TextBox { Dock = DockStyle.Fill };
    private readonly TextBox comment = new TextBox { Dock = DockStyle.Fill, Multiline = true, Height = 76, ScrollBars = ScrollBars.Vertical };
    private readonly Button post = new Button { Text = "Post screenshot", AutoSize = true };
    private readonly Button close = new Button { Text = "Close", AutoSize = true, DialogResult = DialogResult.Cancel };
    private readonly Label status = new Label { AutoSize = true, MaximumSize = new Size(480, 0) };
    private readonly Bitmap image;
    private readonly string filename;
    private bool sending;
    internal bool Posted { get; private set; }
    internal string Token { get { return token.Text.Trim(); } }
    internal string ChannelId { get { return channel.Text.Trim(); } }

    internal SlackDialog(string rememberedToken, string rememberedChannel, Bitmap image, string filename)
    {
        this.image = image;
        this.filename = filename;
        Text = "Post to Slack";
        Font = new Font("Segoe UI", 10);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = MinimizeBox = false;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.CenterParent;
        AutoSize = true;
        AutoSizeMode = AutoSizeMode.GrowAndShrink;
        token.Text = rememberedToken;
        channel.Text = rememberedChannel;
        comment.MaxLength = 3000;
        CancelButton = close;
        var fields = new TableLayoutPanel { AutoSize = true, Dock = DockStyle.Fill, ColumnCount = 2, Padding = new Padding(16) };
        fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155));
        fields.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 330));
        var help = new Label { Text = "Post the current annotated screenshot as your Slack bot. The token stays in memory until Snip Lab closes.", AutoSize = true, MaximumSize = new Size(480, 0), Margin = new Padding(3, 3, 3, 14) };
        fields.Controls.Add(help, 0, 0);
        fields.SetColumnSpan(help, 2);
        AddField(fields, 1, "Slack bot token", token);
        AddField(fields, 2, "Channel ID", channel);
        AddField(fields, 3, "Optional comment", comment);
        fields.Controls.Add(status, 0, 4);
        fields.SetColumnSpan(status, 2);
        var buttons = new FlowLayoutPanel { FlowDirection = FlowDirection.RightToLeft, AutoSize = true, Dock = DockStyle.Fill };
        buttons.Controls.Add(close);
        buttons.Controls.Add(post);
        fields.Controls.Add(buttons, 0, 5);
        fields.SetColumnSpan(buttons, 2);
        Controls.Add(fields);
        post.Click += delegate { Post(); };
    }

    private static void AddField(TableLayoutPanel fields, int row, string label, Control input)
    {
        fields.Controls.Add(new Label { Text = label, AutoSize = true, Anchor = AnchorStyles.Left }, 0, row);
        fields.Controls.Add(input, 1, row);
    }

    private void Post()
    {
        string destination = ChannelId;
        string secret = Token;
        string message = comment.Text.Trim();
        if (!Regex.IsMatch(secret, @"^xoxb-[A-Za-z0-9-]+$") || !Regex.IsMatch(destination, @"^[CG][A-Z0-9]+$"))
        {
            status.Text = "Enter a bot token beginning xoxb- and a Slack channel ID beginning C or G.";
            return;
        }

        if (MessageBox.Show(this, "Post the annotated screenshot to Slack channel " + destination + "?",
            "Confirm Slack post", MessageBoxButtons.YesNo, MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2) != DialogResult.Yes) return;

        byte[] bytes;
        try
        {
            using (MemoryStream png = new MemoryStream())
            {
                image.Save(png, ImageFormat.Png);
                bytes = png.ToArray();
            }
        }
        catch (Exception)
        {
            status.Text = "Could not prepare the screenshot. Try saving the PNG or copying the image.";
            return;
        }

        sending = true;
        token.Enabled = channel.Enabled = comment.Enabled = post.Enabled = close.Enabled = false;
        status.Text = "Uploading screenshot…";
        var worker = new BackgroundWorker();
        worker.DoWork += delegate { SlackUpload.Send(secret, destination, message, filename, bytes); };
        worker.RunWorkerCompleted += delegate(object sender, RunWorkerCompletedEventArgs result)
        {
            worker.Dispose();
            sending = false;
            if (result.Error == null)
            {
                Posted = true;
                DialogResult = DialogResult.OK;
                return;
            }

            token.Enabled = channel.Enabled = comment.Enabled = post.Enabled = close.Enabled = true;
            var known = result.Error as SlackUploadException;
            status.Text = known == null
                ? "Slack could not confirm the post. Check the channel before retrying."
                : known.Message;
        };
        worker.RunWorkerAsync();
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (sending) e.Cancel = true;
        base.OnFormClosing(e);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) image.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class SlackUploadException : Exception
{
    internal SlackUploadException(string message) : base(message) { }
}

internal static class SlackUpload
{
    internal static void Send(string token, string channel, string comment, string name, byte[] png)
    {
        ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072; // TLS 1.2
        Dictionary<string, object> ticket = Call("files.getUploadURLExternal", token,
            "filename=" + Uri.EscapeDataString(name) + "&length=" + png.Length.ToString(CultureInfo.InvariantCulture));

        Uri url;
        if (!Uri.TryCreate(Value(ticket, "upload_url"), UriKind.Absolute, out url) ||
            url.Scheme != Uri.UriSchemeHttps || !url.IsDefaultPort ||
            !String.Equals(url.Host, "files.slack.com", StringComparison.OrdinalIgnoreCase))
            throw new SlackUploadException("Slack returned an unexpected upload address.");

        string fileId = Value(ticket, "file_id");
        if (!Regex.IsMatch(fileId, @"^F[A-Z0-9]+$"))
            throw new SlackUploadException("Slack returned an unexpected file ID.");

        using (HttpWebResponse response = Post(url, "application/octet-stream", png, null))
        {
            if (response.StatusCode != HttpStatusCode.OK)
                throw new SlackUploadException("Slack did not accept the PNG.");
        }

        string files = new JavaScriptSerializer().Serialize(new[] { new { id = fileId, title = name } });
        string payload = "files=" + Uri.EscapeDataString(files) + "&channel_id=" + Uri.EscapeDataString(channel);
        if (comment.Length > 0) payload += "&initial_comment=" + Uri.EscapeDataString(comment);
        Call("files.completeUploadExternal", token, payload);
    }

    private static string Value(Dictionary<string, object> result, string key)
    {
        object value;
        return result.TryGetValue(key, out value) ? value as string ?? "" : "";
    }

    private static Dictionary<string, object> Call(string method, string token, string data)
    {
        var uri = new Uri("https://slack.com/api/" + method);
        using (HttpWebResponse response = Post(uri, "application/x-www-form-urlencoded", Encoding.UTF8.GetBytes(data), token))
        using (var reader = new StreamReader(response.GetResponseStream()))
        {
            var result = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(reader.ReadToEnd());
            object ok;
            if (result != null && result.TryGetValue("ok", out ok) && Object.Equals(ok, true)) return result;
            string error = result == null ? "" : Value(result, "error");
            if (!Regex.IsMatch(error, @"^[a-z0-9_]{1,80}$")) error = "unknown_error";
            throw new SlackUploadException("Slack returned " + error + ". Check the token, files:write permission and channel membership.");
        }
    }

    private static HttpWebResponse Post(Uri uri, string type, byte[] bytes, string token)
    {
        var request = (HttpWebRequest)WebRequest.Create(uri);
        request.Method = "POST";
        request.ContentType = type;
        request.ContentLength = bytes.Length;
        request.Timeout = 30000;
        request.ReadWriteTimeout = 30000;
        request.AllowAutoRedirect = false;
        if (token != null) request.Headers[HttpRequestHeader.Authorization] = "Bearer " + token;
        try
        {
            using (Stream stream = request.GetRequestStream())
                stream.Write(bytes, 0, bytes.Length);
            return (HttpWebResponse)request.GetResponse();
        }
        catch (WebException ex)
        {
            if (ex.Response != null) ex.Response.Close();
            throw;
        }
    }
}
