# Snip Lab 0.2.0-beta

- Scroll over the image to zoom around the pointer. Drag with Hand or the
  middle mouse button to move the image. Fit resets the view.
- Use Line to draw straight annotations and Ctrl+Z to undo them.
- Save image offers PNG and JPEG at the original capture resolution.
- The launcher prompts you to extract the ZIP if the source files or icon
  are missing.

Windows testing of this update is pending.

Scrolling in the empty margin now leaves the snip view unchanged.

## Snip Lab 0.1.0-beta

Windows test package for region capture, QA annotations, PNG export, clipboard
copy, a bug report template and optional direct Slack posting.

This package includes a multi-size Windows app icon, executable version
metadata, an in-app About dialog and first-launch instructions. The executable
is built locally by Launch-Snip-Lab.cmd.

## Shortcut hint fix

The empty capture screen follows the hotkey registration result. When
Ctrl+Shift+F9 is available, the hint shows that shortcut. When unavailable,
it shows New snip or Ctrl+N.

## Reported validation on 10 November 2026

The tester verified both hint states on Windows 11 26H2 and reported that all
seven default regression checks passed.

## Open validation

- Complete a capture using New snip when the global shortcut is unavailable.
- Complete a capture using Ctrl+N when the global shortcut is unavailable.

Mixed-DPI behaviour and live Slack posting remain unverified in this record.
