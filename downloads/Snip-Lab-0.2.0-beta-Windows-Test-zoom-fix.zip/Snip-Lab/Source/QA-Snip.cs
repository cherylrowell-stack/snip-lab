﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows.Forms;

internal static class Program
{
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [STAThread]
    private static void Main()
    {
        SetProcessDPIAware();
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new Editor());
    }
}

internal static class Geometry
{
    internal static Rectangle Between(Point a, Point b)
    {
        return Rectangle.FromLTRB(Math.Min(a.X, b.X), Math.Min(a.Y, b.Y),
            Math.Max(a.X, b.X), Math.Max(a.Y, b.Y));
    }
}

internal sealed class Selection : Form
{
    private readonly Bitmap desktop;
    private bool dragging;
    private Point anchor;
    private Point cursor;
    internal Rectangle RegionPixels { get; private set; }

    internal Selection(Bitmap desktop, Rectangle bounds)
    {
        this.desktop = desktop;
        AutoScaleMode = AutoScaleMode.None;
        FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual;
        Bounds = bounds;
        ShowInTaskbar = false;
        TopMost = true;
        DoubleBuffered = true;
        Cursor = Cursors.Cross;
        KeyPreview = true;
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape) DialogResult = DialogResult.Cancel;
        base.OnKeyDown(e);
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (e.Button != MouseButtons.Left) return;
        anchor = cursor = e.Location;
        dragging = true;
        Capture = true;
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (!dragging) return;
        cursor = e.Location;
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (!dragging || e.Button != MouseButtons.Left) return;
        dragging = false;
        Capture = false;
        RegionPixels = Rectangle.Intersect(Geometry.Between(anchor, e.Location), ClientRectangle);
        if (RegionPixels.Width > 1 && RegionPixels.Height > 1)
            DialogResult = DialogResult.OK;
        else
            Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        Graphics g = e.Graphics;
        g.DrawImageUnscaled(desktop, Point.Empty);
        using (Brush shade = new SolidBrush(Color.FromArgb(135, 6, 12, 22)))
            g.FillRectangle(shade, ClientRectangle);
        if (dragging)
        {
            Rectangle region = Rectangle.Intersect(Geometry.Between(anchor, cursor), ClientRectangle);
            if (region.Width > 0 && region.Height > 0)
            {
                g.DrawImage(desktop, region, region, GraphicsUnit.Pixel);
                g.DrawRectangle(Pens.DeepSkyBlue, region);
            }
            return;
        }

        // Place the hint on the active monitor even when monitors leave gaps.
        Rectangle monitor = RectangleToClient(Screen.FromPoint(MousePosition).Bounds);
        Rectangle hint = new Rectangle(monitor.Left + 24, monitor.Top + 24, 330, 42);
        g.FillRectangle(Brushes.Black, hint);
        TextRenderer.DrawText(g, "Drag to snip  |  Esc to cancel", Font, hint,
            Color.White, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
    }
}

internal enum MarkKind { Arrow, Line, Box, Step, Redact, Hand }

internal sealed class Mark
{
    internal MarkKind Kind;
    internal Point A;
    internal Point B;
    internal int Number;

    internal void Draw(Graphics g)
    {
        Rectangle area = Geometry.Between(A, B);
        switch (Kind)
        {
            case MarkKind.Redact:
                SmoothingMode smoothing = g.SmoothingMode;
                g.SmoothingMode = SmoothingMode.None;
                g.FillRectangle(Brushes.Black, area);
                g.SmoothingMode = smoothing;
                break;
            case MarkKind.Box:
                using (Pen pen = new Pen(Color.OrangeRed, 4))
                    g.DrawRectangle(pen, area);
                break;
            case MarkKind.Line:
                using (Pen pen = new Pen(Color.OrangeRed, 4))
                    g.DrawLine(pen, A, B);
                break;
            case MarkKind.Arrow:
                using (Pen pen = new Pen(Color.OrangeRed, 4))
                using (AdjustableArrowCap head = new AdjustableArrowCap(4, 5))
                {
                    pen.CustomEndCap = head;
                    g.DrawLine(pen, A, B);
                }
                break;
            case MarkKind.Step:
                Rectangle badge = new Rectangle(A.X - 16, A.Y - 16, 32, 32);
                g.FillEllipse(Brushes.OrangeRed, badge);
                g.DrawEllipse(Pens.White, badge);
                using (Font font = new Font("Segoe UI", 14, FontStyle.Bold, GraphicsUnit.Pixel))
                using (StringFormat format = new StringFormat())
                {
                    format.Alignment = StringAlignment.Center;
                    format.LineAlignment = StringAlignment.Center;
                    g.DrawString(Number.ToString(CultureInfo.InvariantCulture), font, Brushes.White, badge, format);
                }
                break;
        }
    }
}

internal sealed class SnipCanvas : Control
{
    private readonly List<Mark> marks = new List<Mark>();
    private Bitmap image;
    private Mark pending;
    private double zoom = 1;
    private Point pan;
    private Point dragStart;
    private Point panStart;
    private MouseButtons panButton;
    private MarkKind tool = MarkKind.Arrow;

    internal MarkKind Tool
    {
        get { return tool; }
        set
        {
            tool = value;
            Cursor = tool == MarkKind.Hand ? Cursors.Hand : Cursors.Default;
        }
    }
    internal bool HotkeyAvailable { get; set; }
    internal bool HasImage { get { return image != null; } }
    internal Size ImageSize { get { return image == null ? Size.Empty : image.Size; } }

    internal SnipCanvas()
    {
        DoubleBuffered = true;
        ResizeRedraw = true;
        BackColor = Color.FromArgb(17, 24, 39);
        ForeColor = Color.FromArgb(216, 228, 242);
        Dock = DockStyle.Fill;
    }

    internal void SetImage(Bitmap value)
    {
        if (image != null) image.Dispose();
        image = value;
        marks.Clear();
        pending = null;
        panButton = MouseButtons.None;
        Capture = false;
        ResetView();
    }

    internal void Undo()
    {
        if (marks.Count == 0) return;
        marks.RemoveAt(marks.Count - 1);
        Invalidate();
    }

    internal void ResetView()
    {
        zoom = 1;
        pan = Point.Empty;
        Invalidate();
    }

    private Rectangle ImageBounds()
    {
        if (!HasImage) return Rectangle.Empty;
        double ratio = Math.Min(1, Math.Min((double)Math.Max(1, Width - 32) / image.Width,
            (double)Math.Max(1, Height - 32) / image.Height));
        int width = Math.Max(1, (int)Math.Round(image.Width * ratio * zoom));
        int height = Math.Max(1, (int)Math.Round(image.Height * ratio * zoom));
        return new Rectangle((Width - width) / 2 + pan.X, (Height - height) / 2 + pan.Y, width, height);
    }

    private static int ClampPan(int offset, int viewSize, int imageSize)
    {
        int visible = Math.Min(24, Math.Min(viewSize, imageSize));
        int centre = (viewSize - imageSize) / 2;
        return Math.Max(visible - imageSize - centre, Math.Min(viewSize - visible - centre, offset));
    }

    private void LimitPan()
    {
        if (!HasImage) return;
        Rectangle bounds = ImageBounds();
        pan = new Point(ClampPan(pan.X, Width, bounds.Width), ClampPan(pan.Y, Height, bounds.Height));
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);
        LimitPan();
    }

    protected override void OnMouseEnter(EventArgs e)
    {
        base.OnMouseEnter(e);
        if (HasImage && !Capture) Focus();
    }

    protected override void OnMouseWheel(MouseEventArgs e)
    {
        base.OnMouseWheel(e);
        if (!HasImage || !ClientRectangle.Contains(e.Location) || Capture || e.Delta == 0) return;

        Rectangle before = ImageBounds();
        if (!before.Contains(e.Location)) return;
        double next = Math.Max(0.25, Math.Min(8, zoom * Math.Pow(1.2, e.Delta / 120.0)));
        if (next == zoom) return;
        zoom = next;
        Rectangle after = ImageBounds();
        pan.Offset(
            e.X - after.X - (int)Math.Round((e.X - before.X) * ((double)after.Width / before.Width)),
            e.Y - after.Y - (int)Math.Round((e.Y - before.Y) * ((double)after.Height / before.Height)));
        LimitPan();
        Invalidate();
    }

    private Point ImagePoint(Point point, bool edge)
    {
        Rectangle bounds = ImageBounds();
        int x = Math.Max(0, Math.Min(edge ? bounds.Width : bounds.Width - 1, point.X - bounds.X));
        int y = Math.Max(0, Math.Min(edge ? bounds.Height : bounds.Height - 1, point.Y - bounds.Y));
        return new Point((int)((long)x * image.Width / bounds.Width),
            (int)((long)y * image.Height / bounds.Height));
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        if (pending != null || panButton != MouseButtons.None || !ImageBounds().Contains(e.Location)) return;
        if (e.Button == MouseButtons.Middle || (e.Button == MouseButtons.Left && Tool == MarkKind.Hand))
        {
            panButton = e.Button;
            dragStart = e.Location;
            panStart = pan;
            Cursor = Cursors.Hand;
            Capture = true;
            return;
        }
        if (e.Button != MouseButtons.Left) return;
        Point point = ImagePoint(e.Location, false);
        pending = new Mark { Kind = Tool, A = point, B = point };
        if (Tool == MarkKind.Step)
        {
            pending.Number = 1 + marks.FindAll(mark => mark.Kind == MarkKind.Step).Count;
            marks.Add(pending);
            pending = null;
        }
        else
            Capture = true;
        Invalidate();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (panButton != MouseButtons.None)
        {
            pan = new Point(panStart.X + e.X - dragStart.X, panStart.Y + e.Y - dragStart.Y);
            LimitPan();
            Invalidate();
            return;
        }
        if (pending == null) return;
        pending.B = ImagePoint(e.Location, true);
        Invalidate();
    }

    protected override void OnMouseCaptureChanged(EventArgs e)
    {
        base.OnMouseCaptureChanged(e);
        if (Capture) return;
        panButton = MouseButtons.None;
        Cursor = Tool == MarkKind.Hand ? Cursors.Hand : Cursors.Default;
        if (pending == null) return;
        pending = null;
        Invalidate();
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        if (panButton != MouseButtons.None && e.Button == panButton)
        {
            Capture = false;
            return;
        }
        if (pending == null || e.Button != MouseButtons.Left) return;
        pending.B = ImagePoint(e.Location, true);
        Rectangle region = Geometry.Between(pending.A, pending.B);
        bool isStroke = pending.Kind == MarkKind.Arrow || pending.Kind == MarkKind.Line;
        if (isStroke ? pending.A != pending.B : region.Width > 0 && region.Height > 0)
            marks.Add(pending);
        pending = null;
        Capture = false;
        Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e)
    {
        if (!HasImage)
        {
            using (Font headline = new Font("Segoe UI", 20, FontStyle.Bold))
                TextRenderer.DrawText(e.Graphics, "Capture your first snip", headline,
                    new Rectangle(0, Height / 2 - 54, Width, 48), ForeColor,
                    TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            string captureHint = HotkeyAvailable
                ? "Click New snip or press Ctrl + Shift + F9"
                : "Click New snip or press Ctrl + N";
            TextRenderer.DrawText(e.Graphics, captureHint, Font,
                new Rectangle(0, Height / 2, Width, 30), ForeColor,
                TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        Rectangle bounds = ImageBounds();
        Graphics g = e.Graphics;
        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
        g.DrawImage(image, bounds, new Rectangle(Point.Empty, image.Size), GraphicsUnit.Pixel);
        GraphicsState state = g.Save();
        g.SetClip(bounds);
        g.TranslateTransform(bounds.X, bounds.Y);
        g.ScaleTransform((float)bounds.Width / image.Width, (float)bounds.Height / image.Height);
        g.SmoothingMode = SmoothingMode.AntiAlias;
        foreach (Mark mark in marks) mark.Draw(g);
        if (pending != null) pending.Draw(g);
        g.Restore(state);
    }

    internal Bitmap Export()
    {
        Bitmap result = new Bitmap(image.Width, image.Height, PixelFormat.Format24bppRgb);
        try
        {
            using (Graphics g = Graphics.FromImage(result))
            {
                g.DrawImageUnscaled(image, Point.Empty);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                foreach (Mark mark in marks) mark.Draw(g);
            }
            return result;
        }
        catch
        {
            result.Dispose();
            throw;
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing && image != null) image.Dispose();
        base.Dispose(disposing);
    }
}

internal sealed class Editor : Form
{
    private const int Hotkey = 1;
    private const int HotkeyMessage = 0x0312;
    [DllImport("user32.dll")]
    private static extern bool RegisterHotKey(IntPtr window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")]
    private static extern bool UnregisterHotKey(IntPtr window, int id);

    private readonly SnipCanvas canvas = new SnipCanvas();
    private readonly ToolStripStatusLabel status = new ToolStripStatusLabel();
    private readonly List<ToolStripItem> captureActions = new List<ToolStripItem>();
    private readonly List<ToolStripButton> tools = new List<ToolStripButton>();
    private readonly Timer captureDelay = new Timer();
    private bool hotkeyAvailable;
    private bool capturing;
    private string channelId = "";
    private string botToken = "";

    private readonly Icon appIcon = System.Drawing.Icon.ExtractAssociatedIcon(Application.ExecutablePath);

    internal Editor()
    {
        Text = AppInfo.Name;
        if (appIcon != null) Icon = appIcon;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(760, 430);
        Size = new Size(1050, 690);
        Font = new Font("Segoe UI", 10);
        var main = new ToolStrip { GripStyle = ToolStripGripStyle.Hidden, Padding = new Padding(8, 5, 8, 5), Font = Font };
        var actions = new ToolStrip { GripStyle = ToolStripGripStyle.Hidden, Padding = new Padding(8, 4, 8, 4), Font = Font };
        var footer = new StatusStrip { Font = Font };
        footer.Items.Add(status);
        Add(main, "New snip", BeginCapture, false).ToolTipText = "Ctrl+N or Ctrl+Shift+F9";
        main.Items.Add(new ToolStripSeparator());
        Add(main, "Copy image", Copy, true).ToolTipText = "Ctrl+C. Paste into Slack or Jira.";
        Add(main, "Save image", Save, true).ToolTipText = "Ctrl+S to save as PNG or JPEG";
        Add(main, "Copy bug template", CopyTemplate, true);
        var slack = new ToolStripDropDownButton("Slack");
        slack.DropDownItems.Add("Copy image for Slack", null, delegate { Copy(); });
        slack.DropDownItems.Add("Post to channel…", null, delegate { ShareSlack(); });
        main.Items.Add(slack);
        captureActions.Add(slack);
        Add(main, "About", ShowAbout, false).ToolTipText = "Version, shortcuts and privacy (F1)";

        AddTool(actions, "Hand", MarkKind.Hand);
        Add(actions, "Fit", delegate { canvas.ResetView(); }, true).ToolTipText = "Reset zoom and position";
        actions.Items.Add(new ToolStripSeparator());
        AddTool(actions, "Arrow", MarkKind.Arrow);
        AddTool(actions, "Line", MarkKind.Line);
        AddTool(actions, "Box", MarkKind.Box);
        AddTool(actions, "Numbered step", MarkKind.Step);
        AddTool(actions, "Redact", MarkKind.Redact);
        actions.Items.Add(new ToolStripSeparator());
        Add(actions, "Undo", Undo, true).ToolTipText = "Ctrl+Z";

        var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Margin = Padding.Empty };
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        layout.Controls.Add(main, 0, 0);
        layout.Controls.Add(actions, 0, 1);
        layout.Controls.Add(canvas, 0, 2);
        layout.Controls.Add(footer, 0, 3);
        Controls.Add(layout);
        UpdateActions();

        captureDelay.Interval = 230;
        captureDelay.Tick += delegate { captureDelay.Stop(); CaptureScreen(); };
    }

    private ToolStripButton Add(ToolStrip strip, string label, Action action, bool needsCapture)
    {
        var button = new ToolStripButton(label);
        button.Click += delegate { action(); };
        strip.Items.Add(button);
        if (needsCapture) captureActions.Add(button);
        return button;
    }

    private void AddTool(ToolStrip strip, string label, MarkKind tool)
    {
        ToolStripButton button = Add(strip, label, delegate
        {
            canvas.Tool = tool;
            foreach (ToolStripButton candidate in tools)
                candidate.Checked = (MarkKind)candidate.Tag == tool;
            status.Text = tool == MarkKind.Hand ? "Drag to move the image. Scroll to zoom."
                : tool == MarkKind.Step ? "Click to place the next numbered step."
                : tool == MarkKind.Redact ? "Drag over sensitive information to cover it."
                : "Drag over the image to draw.";
        }, true);
        button.Tag = tool;
        button.Checked = canvas.Tool == tool;
        tools.Add(button);
    }

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        hotkeyAvailable = RegisterHotKey(Handle, Hotkey, 0x4006, (uint)Keys.F9);
        canvas.HotkeyAvailable = hotkeyAvailable;
        canvas.Invalidate();
        UpdateActions();
    }

    protected override void OnHandleDestroyed(EventArgs e)
    {
        if (hotkeyAvailable) UnregisterHotKey(Handle, Hotkey);
        base.OnHandleDestroyed(e);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == HotkeyMessage && m.WParam.ToInt32() == Hotkey)
        {
            BeginCapture();
            return;
        }
        base.WndProc(ref m);
    }

    protected override bool ProcessCmdKey(ref Message msg, Keys key)
    {
        switch (key)
        {
            case Keys.F1: ShowAbout(); return true;
            case Keys.Control | Keys.N: BeginCapture(); return true;
            case Keys.Control | Keys.C: Copy(); return true;
            case Keys.Control | Keys.S: Save(); return true;
            case Keys.Control | Keys.Z: Undo(); return true;
        }
        return base.ProcessCmdKey(ref msg, key);
    }

    private void UpdateActions()
    {
        foreach (ToolStripItem item in captureActions) item.Enabled = canvas.HasImage;
        Size size = canvas.ImageSize;
        status.Text = canvas.HasImage
            ? String.Format("{0} × {1} px  |  Scroll to zoom  ·  Drag with Hand to move", size.Width, size.Height)
            : hotkeyAvailable ? "Ready  |  Ctrl+Shift+F9 works while Snip Lab is open"
                : "Ready  |  Use New snip or Ctrl+N";
    }

    private void BeginCapture()
    {
        if (capturing || !Enabled || !Visible || OwnedForms.Length != 0) return;
        capturing = true;
        Hide();
        captureDelay.Start();
    }

    private void CaptureScreen()
    {
        string error = null;
        try
        {
            Rectangle bounds = SystemInformation.VirtualScreen;
            using (Bitmap desktop = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format24bppRgb))
            {
                using (Graphics g = Graphics.FromImage(desktop))
                    g.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size);
                using (Selection selection = new Selection(desktop, bounds))
                    if (selection.ShowDialog() == DialogResult.OK)
                        canvas.SetImage(desktop.Clone(selection.RegionPixels, PixelFormat.Format24bppRgb));
            }
        }
        catch (Exception ex)
        {
            error = ex.Message;
        }
        finally
        {
            capturing = false;
            Show();
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal;
            Activate();
            UpdateActions();
        }
        if (error != null) ShowError("Capture failed", error);
    }

    private static string FileName()
    {
        return "qa-snip-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture) + ".png";
    }

    private void Copy()
    {
        if (!canvas.HasImage) return;
        try
        {
            using (Bitmap image = canvas.Export()) Clipboard.SetImage(image);
            status.Text = "Image copied. Paste it into Slack, Jira or a document.";
        }
        catch (Exception ex) { ShowError("Copy failed", ex.Message); }
    }

    private void Save()
    {
        if (!canvas.HasImage) return;
        using (SaveFileDialog dialog = new SaveFileDialog
        {
            Filter = "PNG image (*.png)|*.png|JPEG image (*.jpg, *.jpeg)|*.jpg;*.jpeg",
            FileName = System.IO.Path.GetFileNameWithoutExtension(FileName())
        })
        {
            dialog.FileOk += delegate(object sender, System.ComponentModel.CancelEventArgs e)
            {
                string extension = System.IO.Path.GetExtension(dialog.FileName).ToLowerInvariant();
                if (extension == ".png" || extension == ".jpg" || extension == ".jpeg") return;
                e.Cancel = true;
                ShowError("Save image", "Use a .png, .jpg or .jpeg file extension.");
            };
            if (dialog.ShowDialog(this) != DialogResult.OK) return;
            try
            {
                string extension = System.IO.Path.GetExtension(dialog.FileName);
                ImageFormat format = extension.Equals(".png", StringComparison.OrdinalIgnoreCase)
                    ? ImageFormat.Png : ImageFormat.Jpeg;
                using (Bitmap image = canvas.Export()) image.Save(dialog.FileName, format);
                status.Text = "Saved " + System.IO.Path.GetFileName(dialog.FileName);
            }
            catch (Exception ex) { ShowError("Save failed", ex.Message); }
        }
    }

    private void CopyTemplate()
    {
        if (!canvas.HasImage) return;
        Size size = canvas.ImageSize;
        string template = String.Format("Summary\r\n\r\nEnvironment (build, URL, browser, OS)\r\n\r\nSteps to reproduce\r\n1. \r\n\r\nExpected result\r\n\r\nActual result\r\n\r\nEvidence\r\nScreenshot: {0} × {1} px\r\n", size.Width, size.Height);
        try
        {
            Clipboard.SetText(template);
            status.Text = "Bug template copied. Paste it first, then copy and paste the image.";
        }
        catch (Exception ex) { ShowError("Copy failed", ex.Message); }
    }

    private void Undo()
    {
        canvas.Undo();
        UpdateActions();
    }

    private void ShareSlack()
    {
        if (!canvas.HasImage) return;
        using (SlackDialog dialog = new SlackDialog(botToken, channelId, canvas.Export(), FileName()))
        {
            dialog.ShowDialog(this);
            botToken = dialog.Token;
            channelId = dialog.ChannelId;
            if (dialog.Posted) status.Text = "Posted screenshot to Slack channel " + channelId + ".";
        }
    }

    private void ShowAbout()
    {
        MessageBox.Show(this,
            AppInfo.Name + " " + AppInfo.Release + Environment.NewLine +
            AppInfo.Description + Environment.NewLine + Environment.NewLine +
            "Ctrl+Shift+F9  Capture while Snip Lab is running" + Environment.NewLine +
            "Ctrl+C  Copy image    Ctrl+S  Save PNG or JPEG    Ctrl+Z  Undo" + Environment.NewLine +
            "Scroll to zoom. Use Hand or middle-button drag to move. Choose Fit to reset." +
            Environment.NewLine + Environment.NewLine +
            "Capture and editing run locally. Direct Slack posting sends the annotated screenshot and optional comment to Slack after confirmation.",
            "About " + AppInfo.Name, MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void ShowError(string title, string message)
    {
        MessageBox.Show(this, message, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) captureDelay.Dispose();
        base.Dispose(disposing);
        if (disposing && appIcon != null) appIcon.Dispose();
    }
}
